
# Bazali — GitHub Pages Website

A simple, mobile-friendly landing page for the Bazali app. Ready to deploy on **GitHub Pages**.

## ✨ What’s included
- `index.html` — One-page site with sections: Hero, How it works, Services, Why Bazali, Support
- `styles.css` — Clean styling with Bazali brand colors
- `script.js` — Small script for the footer year
- `assets/logo.png` — Logo (if available)
- `.nojekyll` — Ensures GitHub Pages serves assets as-is

---

## 🚀 Deploy on GitHub Pages (Desktop or Mobile Browser)

1. Create a **new repository** on GitHub (e.g., `bazali-site`).
2. Upload all files in this folder to the repo **root** (not inside a subfolder).
   - On mobile: open the repo → **Add file** → **Upload files** → select all files.
3. Go to **Settings → Pages**.
4. Under “Build and deployment”:
   - Source: **Deploy from a branch**
   - Branch: **main** (/**root**)
5. Click **Save**. Wait ±1–2 minutes.
6. Your site will be live at: `https://YOUR-USERNAME.github.io/bazali-site`

> Tip: If you don’t see it after a few minutes, re-open the Pages settings to confirm it deployed successfully.

---

## 🔗 Update Support Links
In `index.html`, search for the **Support** section and replace:
- WhatsApp: `https://wa.me/27820000000` → your number in international format
- Email: `support@bazaliapp.com` → your address

---

## 🖌 Customise
- Change colors in `styles.css` under `:root { ... }`.
- Replace `assets/logo.png` with your logo file (same name).

---

## 🧰 Optional (Custom Domain)
If you own a domain (like `bazaliapp.com`):
1. In the repo, go to **Settings → Pages**.
2. Click **Add custom domain** and follow GitHub’s DNS instructions (create a `CNAME` record).

Enjoy!
